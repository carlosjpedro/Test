var builder = DistributedApplication.CreateBuilder(args);

var apiService = builder.AddProject<Projects.Maintenance_ApiService>("apiservice");

builder.AddProject<Projects.Maintenance_Web>("webfrontend")
    .WithExternalHttpEndpoints()
    .WithReference(apiService)
    .WaitFor(apiService);

builder.Build().Run();
