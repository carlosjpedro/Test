namespace Maintenance.Web;

public class TaskCategory(string categoryName)
{
    private readonly string _categoryName = categoryName;
}