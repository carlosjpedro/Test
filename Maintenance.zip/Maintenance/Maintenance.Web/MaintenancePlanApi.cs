using System.Collections.Generic;
using Maintenance.Web.Model;

namespace Maintenance.Web;

public class MaintenancePlanApi(HttpClient httpClient)
{
    public async Task<WeatherForecast[]> GetWeatherAsync(int maxItems = 10, CancellationToken cancellationToken = default)
    {
        List<WeatherForecast>? forecasts = null;

        await foreach (var forecast in httpClient.GetFromJsonAsAsyncEnumerable<WeatherForecast>("/weatherforecast", cancellationToken))
        {
            if (forecasts?.Count >= maxItems)
            {
                break;
            }
            if (forecast is not null)
            {
                forecasts ??= [];
                forecasts.Add(forecast);
            }
        }

        return forecasts?.ToArray() ?? [];
    }

    public async Task<MaintenancePlan[]> GetMaintenancePlansAsync(int maxItems = 10, CancellationToken cancellationToken = default)
    {
        var plans = new List<MaintenancePlan>(maxItems);
        await foreach (var plan in httpClient.GetFromJsonAsAsyncEnumerable<MaintenancePlan>("/maintenanceplan", cancellationToken))
        {
            if (plan is null) continue;
            
            plans.Add(plan);

            if (plans?.Count >= maxItems)
            {
                break;
            }
        }
        return plans?.ToArray() ?? [];
    }
}