using Maintenance.Web.Model;

namespace Maintenance.Web;

public class PlanApiClient
{
    public async Task<MaintenancePlan[]> GetPlansAsync()
    {
        return Enumerable.Range(0, 100).Select(x => new MaintenancePlan($"Plan_{x}")).ToArray();
    }
}