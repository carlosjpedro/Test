namespace Maintenance.Web.Model;

public class Name(string value)
{
    private readonly string _value = value.Length == 0 ? throw new ArgumentException("Names cannot be empty", nameof(value)) : value;

    public static implicit operator Name(string name)
    {
        return new Name(name);
    }

    public static implicit operator string(Name name)
    {
        return name._value;
    }
}