namespace Maintenance.Web.Model;

public class Interval(TimeSpan duration)
{
    private readonly TimeSpan _duration = duration;

    public static DateTime operator +(DateTime date, Interval interval)
    {
        return date.Add(interval._duration);
    }

    public static DateTime operator -(DateTime date, Interval interval)
    {
        return date.Add(-interval._duration);
    }
}