namespace Maintenance.Web.Model;

public class Currency
{
    public Currency(string code)
    {
        Code = code.Length is < 2 or > 3 ? throw new ArgumentException("Currency codes must have between 2 and 3 characters", nameof(code)) : code;
    }

    public string Code { get; }
}