namespace Maintenance.Web.Model;

public class MaintenancePlan(Name name, IEnumerable<MaintenanceTask>? tasks = default)
{
    public Name Name { get; } = name;
    private readonly IEnumerable<MaintenanceTask> _tasks = tasks ?? [];
}