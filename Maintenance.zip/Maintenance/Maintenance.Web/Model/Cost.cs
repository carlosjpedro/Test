namespace Maintenance.Web.Model;

public class Cost(decimal value)
{
    private decimal Value { get; } = value < 0 ? throw new ArgumentException("Cost has to be a positive number", nameof(value)) : value;

    public static Cost operator +(Cost first, Cost second)
    {
        return new Cost(first.Value + second.Value);
    }
}