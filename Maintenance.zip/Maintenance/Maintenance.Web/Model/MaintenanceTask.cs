namespace Maintenance.Web.Model;

public class MaintenanceTask(TaskCategory category, Interval interval, Cost cost)
{
    private readonly TaskCategory _category = category;
    private readonly Interval _interval = interval;
    private readonly Cost _cost = cost;
}